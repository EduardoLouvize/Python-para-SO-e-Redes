# Explique a principal semelhança e a principal diferença entre os comandos psutil.pids e psutil.process_iter.
'''
A semelhança é que os dois comandos servem para acessar os PIDs dos processos em execução.

A diferença está na forma de implementação.
O comando psutil.process_iter é mais eficiente para execução repetida.
'''
