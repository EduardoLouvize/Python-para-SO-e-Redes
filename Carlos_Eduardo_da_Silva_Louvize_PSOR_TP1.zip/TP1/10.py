# Os comandos os.exec* e os.spawn* são bastante parecidos. No entanto, eles apresentam uma diferença em suas execuções.
# Aponte qual é está diferença.
'''
O comando os.spawn lança um novo processo para executar o programa chamado, enquanto os. exec executa o novo programa
substituindo o processo corrente.
'''