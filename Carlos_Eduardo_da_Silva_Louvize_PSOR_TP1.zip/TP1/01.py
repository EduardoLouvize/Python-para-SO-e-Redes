# Escreva um programa usando o módulo ‘os’ de Python que imprima o nome de usuário.
import os

print(f"Nome do usuário: {os.getlogin()}")
